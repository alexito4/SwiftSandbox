//: Error Handling in Swift 2.0

import Cocoa

//: We define a custom error enum so we can have custom informaiton about the error.

enum MyError: ErrorType {
    case 💣
    case 💔
}

//: # Using Result 
//: we can return a Result.Failure with an instance of our custom error.

enum Result<T, E: ErrorType> {
    case Success(T)
    case Failure(E)
}


func explodeResult() -> Result<String, MyError> {
    return .Failure(.💣)
}

let explosion = explodeResult()

//: The good part of working with a Result type is that we can leverage the compiler to enforce that the error cases are handled. If we want to print the result of the Explosion we have to unwrap it from the Result.

switch explosion {
case .Success(let explosion):
    print("It has been an awsome explosion \(explosion)")
case .Failure(let error):
    switch error {
    case .💣:
        print("I think we killed ourselves")
    case .💔:
        print("Uops, for ever alone")
    }
}

// Ignore the error information
switch explosion {
case .Success(let explosion):
    print("It has been an awsome explosion \(explosion)")
case .Failure(let error):
    print("Woo error!")
}

//: Now, if we don't care about the error at all we still can ignore its value, just don't implement the nested switch. We can even avoid switches at all with some extension to in type, but this could be something that the language could provide.

extension Result {
    var value: T? {
        switch self {
        case .Success(let ok):
                return ok
        case .Failure(_):
            return nil
        }
    }
}

explosion.value.map { print("It has been an awsome explosion \($0)") }


//: # Using new Swift Error Handling Model

func explodeThrow() throws -> String {
    throw MyError.💔
    return "Yeee 👏🏻"
}

// class to workaround hanging the Playground in Xcode7b1
class AvoidBreakingPlayground {
    static func test() {
        do {
            let text = try explodeThrow()
            print(text)
        } catch MyError.💣 {
            print("I think we killed ourselves")
        } catch MyError.💔 {
            print("Uops, for ever alone")
        } catch (let error) { // THIS WILL NEVER HAPPEN
            print("Some error: \(error)")
        }
    }
}


AvoidBreakingPlayground.test()

//: In this last example you can see the part that I don´t like about this. The compiler can not help us when handling the error. I have a catch that will never happen. And I have to read the documentaiton or know the implementation to know wich error cases I have to deal with. For me it feels like the oposite of what the Swift type system is trying to give us.





