//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//: # Stack

protocol Stack {
    typealias Element
    
    mutating func push(value: Element)
    mutating func pop() -> Element?
}

// Non-essential operations, can be implemented using the essential ones.
extension Stack {
    
    mutating func isEmpty() -> Bool {
        if let value = pop() {
            push(value)
            return false
        } else {
            return true
        }
    }
    
    mutating func top() -> Element? {
        let top = pop()
        if let value = top {
            push(value)
        }
        return top
    }
    
}

//: ## ArrayStack

struct ArrayStack<T>: Stack {
    typealias Element = T
    
    private var contents = Array<Element>()
    
    mutating func push(value: Element) {
        contents.append(value)
    }
    
    mutating func pop() -> Element? {
//        return isEmpty() ? .None : contents.removeLast() // calling isEmpty from here crashes the compiler
        return contents.isEmpty ? .None : contents.removeLast()
    }
    
//    mutating func isEmpty() -> Bool {
//        return contents.isEmpty
//    }
}

extension ArrayStack : CustomStringConvertible, CustomDebugStringConvertible {
    var description: String {
        return contents.description
    }
    
    var debugDescription: String {
        return description
    }
}

var arr = ArrayStack<Int>()
arr.push(1)
arr.push(2)
//arr.count()
//arr
arr.pop()
arr.isEmpty() // calling isEmpty here works just fine!
arr.top()
arr.top()
arr.pop()
arr.isEmpty()

//: ## EnumStack

enum EnumStack<T>: Stack {
    typealias Element = T
    
    case Empty
    indirect case Content(value: Element, previous: EnumStack<Element>)
    
    init() {
        self = .Empty
    }
    
    mutating func push(value: Element) {
        self = .Content(value: value, previous: self)
    }
    
    mutating func pop() -> Element? {
        switch self {
        case .Empty: return .None
        case .Content(let value, let previous):
            self = previous
            return value
        }
    }

}



var lin = EnumStack<Int>()
lin.push(1)
lin.push(2)
lin.pop()
lin.isEmpty() // calling isEmpty here works just fine!
lin.top()
lin.top()
lin.pop()
lin.isEmpty()

//: ## ClassStack

class ClassStack<T>: Stack {
    typealias Element = T

    var data: Element?
    var previous: ClassStack<Element>?
    var last: ClassStack<Element>!
    
    init() {
        data = .None
        previous = .None
        last = self
    }
    
    func push(value: Element) {
        guard data != nil else { // first element
            data = value;
            return;
        }
        
        let s = ClassStack()
        s.data = value
        s.previous = last
        
        last = s
    }
    
    func pop() -> Element? {
        let value = last.data
        last = last.previous
        if last == nil { // first element
            data = .None
            previous = .None
            last = self
        }
        return value
    }
}

var cla = ClassStack<Int>()
var otherCla = cla
cla.push(1)
cla.push(2)
cla.pop()
cla.isEmpty() // calling isEmpty here works just fine!
cla.top()
cla.top()
cla.pop()
cla.isEmpty()

otherCla.isEmpty() // it's a reference type so they share the data




//: # Adding more things to the Protocol

//extension Stack: ArrayLiteralConvertible {
//    
//}

//: Nice to have to make it work better with the language.
//extension Stack where Self: ArrayLiteralConvertible  {
//    
//    init(arrayLiteral elements: Self.Element...) {
//        self.init()
////        print("array literal init")
//        for value in elements {
//            push(value)
//        }
//    }
//    
//}

//extension ArrayStack: ArrayLiteralConvertible {}
//print("before")
//var tin: ArrayStack<Int> = [1, 2, 3]
//print("after")
//: Don't know if it's a good idea to make it be a Sequance. It adds a lot of default functions.
//: Maybe it's easy enought to use a while if someone wants to iterate

//while let value = tin.pop() {
//    print(value)
//}
//tin

//extension Stack {//where Self: SequenceType {
//    mutating func generate() -> AnyGenerator<Element> {
//        return anyGenerator {
//            return self.pop()
//        }
//    }
//}
//
//for value in tin.generate() {
//    print(value)
//}
//tin
//
//let res = tin.generate().map({$0})
//res

//: We could extend the Stack to add more functions but we shouldn't. The whole point of a Stack is to use a
//: restricted data structure. Otherwise just use a more powrfull squence that allows you to do anything.
//: Not like Java https://docs.oracle.com/javase/8/docs/api/java/util/Stack.html
extension Stack {
    mutating func count() -> Int {
        
        var temp = [Element]()
        
        while let value = pop() {
            temp.insert(value, atIndex: 0)
        }
        
        let count = temp.count
        
        for value in temp {
            push(value)
        }
        
        return count
    }
}

cla.push(2)
cla.count()

