// Playground - noun: a place where people can play

import UIKit
import XCPlayground

// Test data
struct Person {
    let name: String
    let priority: Int
}

let people = [
    Person(name: "Alex", priority: 1),
    Person(name: "Anna", priority: 1),
    Person(name: "Julian", priority: 1),
    Person(name: "Andrea", priority: 2),
    Person(name: "Rob", priority: 2),
    Person(name: "John", priority: 2),
    Person(name: "Javi", priority: 4)
]


// Code
// See GroupBy.swift

// Test

let sectioned = people.groupBy { $0.name.characters.first == $1.name.characters.first }

print(sectioned)
sectioned.count

extension Person: Groupable {
    
    func sameGroupAs(otherPerson: Person) -> Bool {
        let f = self.name.characters.first
        let s = otherPerson.name.characters.first
        
        return f == s
    }
    
}

people[0].sameGroupAs(people[1])
people[0].sameGroupAs(people[2])


let autoSectioned = people.group()
print(autoSectioned)
autoSectioned.count

extension Person: Comparable {
}

func < (lhs: Person, rhs: Person) -> Bool {
    return lhs.name < rhs.name
}

func == (lhs: Person, rhs: Person) -> Bool {
    return lhs.name == rhs.name
}


let uniquely = people.uniquelyGroupBy { $0.sameGroupAs($1) }
print(uniquely)
uniquely.count
