import Cocoa

protocol P {
    func a()
//    func b() // enable this to see how p.b() gets also dynamic dispatch
    func c()
}

extension P {
    func a() {
        print("default implementation of A")
    }
    
    func b() {
        print("default implementation of B")
    }
    
    func c() {
        print("default implementation of C")
    }
}

struct S: P {
    func a() {
        print("specialized implementation of A")
    }
    
    func b() {
        print("specialized implementation of B")
    }
}

print("\n as P \n")

let p: P = S()
// we see p as P
p.a() // dynamic dispatch through S -> specialized
p.b() // static dispatch through P -> default
p.c() // dynamic dispatch through P -> default

print("\n as S \n")

let p2 = S()
// we see p2 as S
p2.a() // static dispatch through S -> specialized
p2.b() // static dispatch through S -> specialized
p2.c() // static dispatch through P -> default

print("\n as P \n")

func useP(p : P) {
    p.a() // dynamic dispatch through S -> specialized
    p.b() // static dispatch through P -> default
    p.c() // dynamic dispatch through P -> default
}

useP(p)
useP(p2)

print("\n as S \n")

func useS(s: S) {
    s.a() // static dispatch through S -> specialized
    s.b() // static dispatch through S -> specialized
    s.c() // static dispatch through P -> default
}

//useS(p) nope!
useS(p2)

